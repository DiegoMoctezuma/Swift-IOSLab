import UIKit

var greeting = "Hola Mundo!" //Variables
let nombre = "Yael" //Constante
let apellido: String = "AAAAAA" //Tipado explicito
/*
Int --> Enteros
Float --> Flotantes (Punto decimal)
Double --> Punto decimal
String --> Cadena de texto
Bool --> Boolenanos
*/

//Imprimir
print(greeting)


/* Ejercicio */
//Hacer una variable que contenga tu nombre e imprimirla en consola
let eNombre: String = "Rafael"
print(eNombre)


//Declarar una varible para su edad y otra para su año de nacimiento
var edad: Int = 20
let añoNacimiento: Int = 2003
print(edad + añoNacimiento)
print(edad, añoNacimiento)
print("Hola \(eNombre), yo se que tienes \(edad) años")


//Imprime en pantalla todos tus datos, usando varibles
//Datos: Nombre, apellido, edad, numero de tarjeta, clave de tarjeta
let eApellido: String = "Moctezuma"
let numTarjeta: Int = 12345678910
let claveTarjeta: Int = 1234
/*print("Nombre: \(eNombre)")
 print("Apellido: \(eApellido)")
 print("Edad: \(edad)")
 print("Numero de tarjeta: \(numTarjeta)")
 print("Clave de tarjeta: \(claveTarjeta)")
*/
print("Hola \(eNombre) \(eApellido), tienes \(edad) años y tu numero de tarjeta es: \(numTarjeta), tu clave es: \(claveTarjeta)")

//Ciclo For
for i in 1...10 
{
    print(i) //Se puede usar '_' como varible vacia
}

//Tabla de multiplicar del 7
for i in 1...10 
{
    print("7 X \(i) = \(7*i)")
}


//Condicional if
if edad < 23 {
    print("Tas joven")
} else {
    print("Tas viejo")
}

//Booleanos: Verdadero o Falso
if eNombre == "Rafael" {
    print("El nombre es igual : \(true)")
}else{
    print("El nombre es igual : \(false)")
}
    
var caso: Int = 3

switch caso {
case 0:
    print("Soy 0")
    break
case 1:
    print("Soy 1")
    break
case 2:
    print("Soy 2")
    break
case 3:
    print("Soy 3")
    break
default:
    print("Invalido")
}

//Elegir que opcion realizar usando el switch
print("\n*** Ejercicio Switch ***")
var num1: Int = 5
var num2: Int = 2
var operacion: Int = 2
switch operacion{
case 1:
    print("\(num1) + \(num2) = \(num1+num2)")
    break
case 2:
    print("\(num1) - \(num2) = \(num1-num2)")
    break
case 3:
    print("\(num1) * \(num2) = \(num1*num2)")
    break
case 4:
    print("\(num1) / \(num2) = \(num1/num2)")
    break
default:
    print("Opcion no valida")
}
